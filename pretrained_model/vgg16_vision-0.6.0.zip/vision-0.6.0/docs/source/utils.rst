torchvision.utils
=================

.. currentmodule:: torchvision.utils

.. autofunction:: make_grid

.. autofunction:: save_image

